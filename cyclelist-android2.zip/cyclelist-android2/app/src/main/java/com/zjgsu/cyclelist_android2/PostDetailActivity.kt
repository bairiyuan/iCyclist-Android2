package com.zjgsu.cyclelist_android2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PostDetailActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var post: Post
    private lateinit var tvTitle: TextView
    private lateinit var tvAuthor: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvContent: TextView
    private lateinit var tvLikes: TextView
    private lateinit var ivLike: ImageView
    private lateinit var etComment: EditText
    private lateinit var btnSendComment: Button

    private var isLiked = false
    private var likeCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_post_detail)

        // 获取传递的帖子数据
        post = intent.getSerializableExtra("post") as? Post ?: run {
            // 如果没有传递数据，使用默认数据
            Post(
                id = 1,
                title = "默认帖子标题",
                author = "默认作者",
                time = "刚刚",
                content = "这是默认的帖子内容",
                category = "装备讨论",
                likes = 10,
                comments = 5
            )
        }

        initViews()
        setData()
        setListeners()
    }

    private fun initViews() {
        tvTitle = findViewById(R.id.tv_post_title)
        tvAuthor = findViewById(R.id.tv_post_author)
        tvTime = findViewById(R.id.tv_post_time)
        tvContent = findViewById(R.id.tv_post_content)
        tvLikes = findViewById(R.id.tv_post_likes)
        ivLike = findViewById(R.id.iv_like)
        etComment = findViewById(R.id.et_comment)
        btnSendComment = findViewById(R.id.btn_send_comment)
        findViewById<View>(R.id.ll_like).setOnClickListener(this)
    }

    private fun setData() {
        tvTitle.text = post.title
        tvAuthor.text = "作者: ${post.author}"
        tvTime.text = "发布时间: ${post.time}"
        tvContent.text = post.content
        likeCount = post.likes
        tvLikes.text = likeCount.toString()
    }

    private fun setListeners() {
        btnSendComment.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ll_like -> handleLike()
            R.id.btn_send_comment -> handleSendComment()
        }
    }

    // 处理点赞逻辑
    private fun handleLike() {
        isLiked = !isLiked
        if (isLiked) {
            likeCount++
            ivLike.setImageResource(android.R.drawable.btn_star_big_on)
            Toast.makeText(this, "点赞成功", Toast.LENGTH_SHORT).show()
        } else {
            likeCount--
            ivLike.setImageResource(android.R.drawable.btn_star_big_off)
            Toast.makeText(this, "取消点赞", Toast.LENGTH_SHORT).show()
        }
        tvLikes.text = likeCount.toString()
    }

    // 处理发送评论
    private fun handleSendComment() {
        val comment = etComment.text.toString().trim()
        if (comment.isEmpty()) {
            Toast.makeText(this, "请输入评论内容", Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(this, "评论发送成功: $comment", Toast.LENGTH_SHORT).show()
        etComment.text.clear()
    }
}