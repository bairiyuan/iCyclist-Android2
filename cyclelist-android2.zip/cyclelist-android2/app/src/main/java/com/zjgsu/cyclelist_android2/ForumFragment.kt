package com.zjgsu.cyclelist_android2

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ForumFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var postAdapter: PostAdapter
    private val postList = mutableListOf<Post>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.activity_forum, container, false)
        initView(view)
        initData()
        initTabs(view)
        return view
    }

    private fun initView(view: View) {
        recyclerView = view.findViewById(R.id.rv_posts)
        recyclerView.layoutManager = LinearLayoutManager(context)
        postAdapter = PostAdapter(postList) { post ->
            // 点击帖子跳转到详情页
            val intent = Intent(context, PostDetailActivity::class.java)
            intent.putExtra("post_id", post.id)
            intent.putExtra("post_title", post.title)
            intent.putExtra("post_author", post.author)
            intent.putExtra("post_time", post.time)
            intent.putExtra("post_content", post.content)
            intent.putExtra("post_likes", post.likes)
            startActivity(intent)
        }
        recyclerView.adapter = postAdapter
    }

    private fun initData() {
        // 模拟帖子数据
        val categories = listOf("装备讨论", "二手交易", "徒步户外", "跑步越野", "运动直播", "自驾摩旅", "有问必答")

        repeat(15) { index ->
            val category = categories[index % categories.size]
            postList.add(
                Post(
                    id = index + 1,
                    title = "$category 的精彩分享 #${index + 1}",
                    author = "骑友${index + 1}",
                    time = "${index + 1}小时前",
                    content = "这是一篇关于$category 的精彩内容，欢迎大家一起来讨论交流！这里有很多有趣的经验分享和实用技巧。",
                    category = category,
                    likes = (10 + index * 3),
                    comments = (5 + index)
                )
            )
        }
        postAdapter.notifyDataSetChanged()
    }

    private fun initTabs(view: View) {
        // 论坛分类标签点击事件
        val tabs = listOf(
            R.id.tv_equipment, R.id.tv_secondhand, R.id.tv_hiking,
            R.id.tv_running, R.id.tv_live, R.id.tv_driving, R.id.tv_qa
        )

        tabs.forEach { tabId ->
            view.findViewById<TextView>(tabId).setOnClickListener {
                // 重置所有标签颜色
                tabs.forEach { id ->
                    view.findViewById<TextView>(id).setTextColor(
                        resources.getColor(android.R.color.darker_gray, null)
                    )
                }
                // 设置当前标签颜色
                (it as TextView).setTextColor(
                    resources.getColor(android.R.color.holo_blue_dark, null)
                )

                // 模拟分类切换
                val categoryText = (it as TextView).text.toString()
                Toast.makeText(context, "切换到: $categoryText", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// 统一的帖子数据类
data class Post(
    val id: Int = 0,
    val title: String,
    val author: String,
    val time: String,
    val content: String,
    val category: String = "装备讨论",
    val likes: Int = 0,
    val comments: Int = 0
)